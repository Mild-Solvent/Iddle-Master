IDLE MASTER REBUILD KIT
=======================

Made by Idle Master 0.6.0 on DESKTOP-B1KSIA9, 2026-08-18 17:32.

On a fresh Windows:

  1. Extract this WHOLE zip somewhere (right-click > Extract All...).
  2. Run IdleMasterRebuild.exe from inside that folder. It asks for administrator.
  3. Tick what you want, press Rebuild, read the log.

What is in here:

  IdleMasterRebuild.exe   the thing that does the work
  rebuild.ini             what you picked, plain text - edit it if you like
  apps.json               5 app(s), winget import format:  winget import -i apps.json
  files\                  2 folder(s)/file(s), exactly as they were
  idlemaster.ini          your Idle Master config

The Windows AI removal (github.com/zoicware/RemoveWindowsAI) and WinUtil
(christitus.com/win) steps download their scripts when they run; they are
not in this kit and need the machine online.

https://github.com/Mild-Solvent/Iddle-Master
